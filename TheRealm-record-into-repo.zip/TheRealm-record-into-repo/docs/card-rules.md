# Card rules for the play-throughs — draft for Phil, 20 October

Step 1 of running the test properly (agreed 19 October): what each card means
for a question, and what counts as a play, written **before** any run. Each
rule is tagged and cited. **[C]** rules are mine and wait on Phil. Nothing
here goes into the record.

## What is a play

1. **[P]** Nine plays a call. Asking her something, asking a coworker, or
   looking something up each uses one. (`settled.md` §2, *Nine plays*)
2. **[P]** The opening is free: the greeting and the universal question.
   (§2)
3. **[P]** Identification is two plays: ask her for something searchable,
   then search on it. (§2)
4. **[P·C]** The aside — asking a coworker over your shoulder while she is
   on the line — is a play. She hears it. (§2, *The aside*; Phil, 19
   October)
5. **[P, 20 October]** Offering a remedy or a fix is a play. What the agent says to
   explain the fix inside the same turn is part of that play, not another.
6. **[P, 20 October]** Next steps cost a play. The goodbye is free.

## Suits — what the question asks for

7. **[P]** Who · What · When · Where · Why · How. (§2, *The six suits*)
8. **[P, 20 October]** The suit is the kind of answer the question asks
   for — a person, a thing or action, a time, a place, a reason, a way of
   doing it — not the question's first word.

## Angles — how the question asks it

9. **[P]** Verify · Validate · Expand · Contract are the four angles;
   Random is the player not choosing. (§2)
10. **[P]** A statement is an inquiry: it invites a yes or a no. (§2, *A
    statement is an inquiry*)
11. **[C·ok, 20 October]** **Validate** checks with her, two ways:
    - **A guess at something she has not said** tests a fact: yes confirms
      it, no corrects it and hands over the right thing.
    - **A paraphrase of what she has said** confirms nothing about the fact
      (Phil, tentative, §2 *Her side, mirrored*), but shows she was heard —
      *paraphrase for comprehension, then act* is one of the soft skills
      that are the mechanic (`docs/handover/memory/therealm-design-frame.md`).
      It costs a play, and her sheet decides what it is worth: repetition
      *high* is settled by it, *low* reads it as not listening, empathy
      *high* can tell whether it was meant.
12. **[C·ok, tentative, 20 October]** **Verify** checks against a source.
    - **At the record:** checks something she said against what TLC holds —
      a lookup, so a play.
    - **At her:** asks her to go and check something she has — her memory,
      her account page, the bag. What comes back can be right or wrong, sure
      or unsure, and neither tells the player the other (Phil, 12 October).
    - Validate: the agent says it, she answers yes or no. Verify: the agent
      asks, she goes and looks.
    - Phil: *"I think so. It's not terribly clear to me, though it seems
      accurate."*
    - **Framing, Phil, 20 October:** not *"So the bag's been set so only you
      can open it?"* but *"Is anyone else in your party able to access the
      bag?"* — ask about what she can know from where she stands, not the
      agent's own guess at the cause in TLC's words.
13. **[P, 20 October] Expand and Contract mean different things at the
    record and at her.**
    - **At the record (CRM searches):** Expand goes outward and down from
      what you have; Contract goes up to the parent — a name, contracted,
      finds the account it belongs to.
    - **With her:** Expand widens the line of inquiry — moving from her name
      and account to the issue at hand is an expansion. Contract focuses and
      continues the line of inquiry already open.
    - Runs 1–19 used my own meaning (Expand an open question, Contract a
      narrowing one); their labels are to be re-checked against this.
14. **[P]** Random: the player does not choose an angle. (§2)

## Targets — what a question can be aimed at

15. **[P]** A single word, already introduced by her or by the record.
    (§2; tentative, *Her side, mirrored*)
16. **[P, 19–20 October]** Words common to every customer are available from
    the start: *name*, *account*, *number*, *email*. Identifying her is
    suits played on them — Who·Name, What·Account, What·Number, Who·Email.
17. **[P, 19 October]** TLC's own internal terms — *permissions*,
    *Assign*, *Admin Only* — are known to the agent from the start.
18. **[P]** One or two inquiries a turn, each labelled on its own. (§2)

## Every play has a target, and most have a suit

19. **[P]** The three target classes: her, the record, a coworker — and the
    target decides the result. (§2, *Targets*) So searching and reading the
    record are suits played at the record, and the aside is a suit played
    at a coworker. Identifying her is suits played on the common words
    (rule 16). *(Phil, 20 October, correcting my draft, which said these
    carried no suit.)*
20. **[P, 20 October]** Offering a fix, next steps and promises are suits
    played on words of their own: What·Fix, What·Solution, Where·Fix,
    Who·Solution, Why·Fix, and so on; Who·Callback, When·Callback. *Fix*,
    *solution* and *callback* are among the words available to the agent.
21. **[P, 20 October]** The goodbye is probably the only move without a
    suit. It closes the call the way the universal opening starts it — where
    the customer shares her reason for contact — and like the opening it is
    free.
